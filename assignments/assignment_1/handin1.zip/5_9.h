#ifndef H_5_9_H
#define H_5_9_H

void solve3by3(double **A, double *b, double *u);

#endif
