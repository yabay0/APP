#ifndef TEST_5_4
#define TEST_5_4

double calc_std(double a[], int length);
double calc_mean(double a[], int length);

#endif
